#ifndef BERT_QEDISLOGO_H
#define BERT_QEDISLOGO_H

const char* qedisLogo = "\n  _____     _____   _____   _   _____ \n"
                        " /  _  \\   | ____| |  _  \\ | | /  ___/\n"
                        " | | | |   | |__   | | | | | | | |___    Qedis(%s) %d bits, another redis written in C++11\n" // version and server bits
                        " | | | |   |  __|  | | | | | | \\___  \\   Port: %d\n"
                        " | |_| |_  | |___  | |_| | | |  ___| |   Author: Bert Young\n"
                        " \\_______| |_____| |_____/ |_| /_____/   https://github.com/loveyacper/Qedis\n\n\n";

#endif

