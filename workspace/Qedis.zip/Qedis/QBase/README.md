# QBase

QBase最初是C++03代码，由于历史原因，再加上它也极其稳定，我不打算替换了。

感兴趣的可以看我的另外一个最新后台开发基础库[ananas](https://github.com/loveyacper/ananas)
